package com.example.leaf_disease

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
